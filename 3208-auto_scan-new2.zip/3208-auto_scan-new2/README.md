# 3208-auto_scan

# Careful the sql statement create does include an extra table for testing and future improvement. only copy paste the first two statements : ticket and users statements (not user)




# WARNING YOU MUST RUN registerAdmin.php to register an admin the other is for members only



# need to encrypt user info when passed in url
# no exception management for input
